# Step 1: Unzipping the zipped folder
# Provide the path to the zip folder
zip_file <- "Employee_Profile.zip"

# Provide the directory you want to extract to
extract_to <- "Employee_Profile"

# Create the directory if it doesn't exist
if (!file.exists(extract_to)) {
  dir.create(extract_to)
}

# Unzip the contents of the zip file to the specified directory
unzip(zip_file, exdir = extract_to)

# List files extracted from the zip archive
extracted_files <- list.files(extract_to, full.names = TRUE)

# Step 2: Reading the contents of the folder
# Display the contents of each extracted file (assuming they are CSVs)
for (file in extracted_files) {
  cat("Contents of", file, ":\n")
  print(read.csv(file))
}